package mainpackage;

public class Main {
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		Ventana v = new Ventana();
		v.setVisible(true);
	}
}
