package ej04;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		Ventana v = new Ventana();
		v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		v.setLocationRelativeTo(null);
		v.setVisible(true);
	}

}
