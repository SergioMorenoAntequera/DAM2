package mainpackage;

import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.Serializable;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author windiurno
 */
public class TfCambiarColor extends JTextField implements Serializable{
    
    private Color colorFondo;
    private FocusListener fl;
    
    //--------------------------------------------------------------------------
    
    public TfCambiarColor() {
        super();
        
        setColorFondo(Color.RED);
        
        //Listener
        this.fl = new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                setBackground(colorFondo);
            }

            @Override
            public void focusLost(FocusEvent e) {
                setBackground(Color.WHITE);
            }
        };
        this.addFocusListener(fl);
    }

    //--------------------------------------------------------------------------
    
    public Color getColorFondo() {
        return colorFondo;
    }
    
    public void setColorFondo(Color colorFondo) {
        this.colorFondo = colorFondo;
        this.setBackground(this.colorFondo);
    } 
}
