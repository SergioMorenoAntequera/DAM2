/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpackage;

import javax.swing.JFrame;

/**
 *
 * @author windiurno
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.add(new Semaforo());
        frame.pack();
        frame.setVisible(true);
    }
    
}
