/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpackage;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.Serializable;
import javax.swing.JTextField;

/**
 *
 * @author windiurno
 */
public class beanEjercicio3 extends JTextField implements Serializable {
    
    private Color color;
    private Font fuente;
    private int columnas;
    
    private String tipo;
    KeyListener listener;
    
    //--------------------------------------------------------------------------
    
    public beanEjercicio3() {
        super();
        
        setColor(Color.BLACK);
        setFuente(new Font("Calibri", Font.BOLD, 15));
        this.tipo = "Texto";
        gestionarTipo();
    }
    
    //--------------------------------------------------------------------------

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
        this.setForeground(this.color);
    }

    public Font getFuente() {
        return fuente;
    }

    public void setFuente(Font fuente) {
        this.fuente = fuente;
        this.setFont(this.fuente);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //--------------------------------------------------------------------------
    
    private void gestionarTipo() {
        //Texto, entero, Real
        listener = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if(tipo == "Entero"){
                    if(!Character.isDigit(e.getKeyChar())){
                       e.consume();
                    }
                }
                if(tipo == "Real"){
                    if(!Character.isDigit(e.getKeyChar())){
                       e.consume();
                    }
                }
                if(tipo == "Texto"){
                    if(Character.isDigit(e.getKeyChar())){
                       e.consume();
                    }
                }
                if(tipo == "SN"){
                    if(e.getKeyChar() != 'S' || e.getKeyChar() != 'N' || getText().length() > 1){
                        e.consume();
                    }
                }  
            }
            @Override
            public void keyPressed(KeyEvent e) {}

            @Override
            public void keyReleased(KeyEvent e) {}
        };
        this.addKeyListener(listener);
    }   
}
