
/*** Creacion de las bases de datos de la práctica ***/ 
drop database if exists multas;
create database if not exists multas;
use multas;
/***  Creación de las tablas, sus relaciones y los datos ****/

/*** TABLA TIPO_INFRACCION ***/
create table if not exists Tipo_infraccion(
	idtipo int(8) primary key auto_increment,
    descripcion text,
    importe float
)engine=innodb;

insert into Tipo_infraccion values(null,'exceso de velocidad','200');
insert into Tipo_infraccion values(null,'mal aparcamiento','100');
insert into Tipo_infraccion values(null,'cinturon no puesto','600');
insert into Tipo_infraccion values(null,'exceso de alcohol','200');
insert into Tipo_infraccion values(null,'semaforo no respetado','500');
COMMIT;


/*** TABLA PERSONA ***/
create table if not exists Persona(
	idpersona int(8) primary key auto_increment,
    nombre varchar(30),
    direccion varchar(50),
    fechaNacimiento date
)engine = innodb;

insert into Persona values(null,'Juan Fernandez Diaz','c/ sierra nº 23, 2ºA','1978-08-23');
insert into Persona values(null,'Alberto Gutierrez Frias','c/ alhamilla nº 2, 1ºA','1968-07-13');
insert into Persona values(null,'Maria Estevez Sanchez','avda. constitucion s/n','1981-11-09');
insert into Persona values(null,'Raquel Fernandez Lopez','plaza castilla, nº11 5ºB','1970-12-12');
insert into Persona values(null,'Francisco Perez Torres','ctra. malaga nº21 4ºC','1974-02-22');
insert into Persona values(null,'Andres Perez Lopez','ctra. jaen nº2 6ºC dcha.','1974-02-22');
insert into Persona values(null,'Carlos Sachez Tejeiro','avda. mediterraneo 45.','1968-03-11');
insert into Persona values(null,'Luis Jimenez Ramirez','plaza de españa, 34 nº12','1979-01-01');


/*** TABLA CONDUCTOR ***/
create table if not exists Conductor(
	idpersona int(8) primary key,
    licencia varchar(10),
    fechaExpiracion date,
    constraint foreign key  (idpersona) references Persona(idpersona)
    on update cascade
    on delete restrict
)engine=innodb;

insert into Conductor values(1,'ciclomotor',curdate());
insert into Conductor values(2,'turismo','2009-04-23');
insert into Conductor values(3,'camion','2005-03-28');
insert into Conductor values(4,'turismo','2008-05-02');
insert into Conductor values(7,'turismo','2009-11-28');
insert into Conductor values(8,'turismo','2006-03-12');
COMMIT;


/*** TABLA POLICIA ***/
create table if not exists Policia(
	idpersona int(8) primary key,
    grado varchar(20),
    nplaca int(8) unique not null,
    constraint foreign key  (idpersona) references Persona(idpersona)
    on update cascade
    on delete restrict
)engine = innodb;

insert into Policia values(5,'sargento',1);
insert into Policia values(6,'teniente',2);
COMMIT;


/********** TABLA MARCA_VEHICULO *************/
create table if not exists Marca_vehiculo(
	idmarca int(8) primary key auto_increment,
    descripcion text,
    pais varchar(30)
)engine = innodb;

insert into Marca_vehiculo values(null,'seat','españa');
insert into Marca_vehiculo values(null,'audi','alemania');
insert into Marca_vehiculo values(null,'nissan','japon');
insert into Marca_vehiculo values(null,'toyota','japon');
insert into Marca_vehiculo values(null,'renault','francia');
insert into Marca_vehiculo values(null,'citroen','francia');
insert into Marca_vehiculo values(null,'yamaha','japon');
insert into Marca_vehiculo values(null,'pegaso','españa');
COMMIT;

/********** TABLA MODELO_VEHICULO *************/
create table if not exists Modelo_vehiculo(
	idmodelo int(8) primary key auto_increment,
    descripcion text
);

insert into Modelo_vehiculo values(null,'audi A3');
insert into Modelo_vehiculo values(null,'renault megane');
insert into Modelo_vehiculo values(null,'seat cordoba');
insert into Modelo_vehiculo values(null,'seat leon');
insert into Modelo_vehiculo values(null,'toyota corola');
insert into Modelo_vehiculo values(null,'citroen c3');
insert into Modelo_vehiculo values(null,'citroen c5');
insert into Modelo_vehiculo values(null,'yamaha nfx 125');
insert into Modelo_vehiculo values(null,'pegaso orion');
COMMIT;


/********** TABLA VEHICULO *************/
create table if not exists Vehiculo(
	idvehiculo int(8) primary key auto_increment,
    idmarca int(8),
    idmodelo int(8),
    idpropietario int(8),
    anno year,
    color varchar(10),
    constraint foreign key (idmarca) references Marca_vehiculo(idmarca)
    on delete cascade
    on update cascade,
    constraint foreign key (idmodelo) references Modelo_vehiculo(idmodelo)
    on delete cascade
    on update cascade,
    constraint foreign key (idpropietario) references Persona(idpersona)
    on delete cascade
    on update cascade
)engine = innodb;

insert into Vehiculo values(null,1,3,2,1990,'rojo');
insert into Vehiculo values(null,1,4,2,1995,'azul');
insert into Vehiculo values(null,6,6,4,2002,'gris');
insert into Vehiculo values(null,7,8,1,1990,'amarillo');
insert into Vehiculo values(null,8,9,3,1997,'blanco');
insert into Vehiculo values(null,4,5,7,1996,'verde');
insert into Vehiculo values(null,2,1,8,2000,'blanco');
insert into Vehiculo values(null,5,2,8,2000,'blanco');
COMMIT;


/*** TABLA PAPELETA_MULTA ***/
create table Papeleta_multa(
	idpapeleta int(8) primary key auto_increment,
    idtipoinfraccion int(8),
    idvehiculo int(8),
    idconductor int(8),
    fecha date,
    idpolicia int(8),
    constraint foreign key (idvehiculo) references Vehiculo(idvehiculo)
    on delete cascade
    on update cascade,
    constraint foreign key (idconductor) references Conductor(idpersona)
    on delete cascade
    on update cascade,
    constraint foreign key (idpolicia) references Policia(idpersona)
    on delete cascade
    on update cascade,
    constraint foreign key (idtipoinfraccion) references Tipo_infraccion(idtipo)
    on delete cascade
    on update cascade
)engine = innodb;

insert into Papeleta_multa values(null, 1, 1, 2, curdate(), 5);
insert into Papeleta_multa values(null, 3, 3, 7, curdate(), 5);
insert into Papeleta_multa values(null, 2, 1, 4, curdate(), 5);
insert into Papeleta_multa values(null, 1, 1, 2, curdate(), 6);
insert into Papeleta_multa values(null, 3, 5, 3, curdate(), 5);
insert into Papeleta_multa values(null, 4, 8, 7, curdate(), 5);
insert into Papeleta_multa values(null, 5, 4, 1, curdate(), 6);
insert into Papeleta_multa values(null, 5, 4, 1, curdate(), 5);
insert into Papeleta_multa values(null, 3, 1, 8, curdate(), 6);
COMMIT;