/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicahibernate;

import entity.Conductor;
import entity.TipoInfraccion;
import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.NewHibernateUtil;

/**
 *
 * @author seran
 */
public class Consulta01 {

    //Tipo de infracción cuya multa supere los 500€
    public static void main(String[] args) {
        SessionFactory sfactory = NewHibernateUtil.getSessionFactory();
    	Session session = sfactory.openSession();
        
        //Creamos un quuery que contiene las filas de la tabla donde el eimporte es mayor
        //o igual a la cantidad requerida
        Query q = session.createQuery("from TipoInfraccion where importe >= " + 500);
        
        Iterator<?> iter = q.iterate();
        
        //Vamos mirando el quuery y como ya estña hecho simplemente mostramos.
        System.out.println("Infracciones que superan los 500€");
        while (iter.hasNext()) {
            // extraer el siguiente objeto
            System.out.println("=================================");
            TipoInfraccion result = (TipoInfraccion) iter.next();
            
            System.out.println("ID: "+ result.getIdtipo() + 
                    "\nInfracción: " + result.getDescripcion() + 
                    "\nImporte: " + result.getImporte());
        }
        session.close();
    }
    
}
