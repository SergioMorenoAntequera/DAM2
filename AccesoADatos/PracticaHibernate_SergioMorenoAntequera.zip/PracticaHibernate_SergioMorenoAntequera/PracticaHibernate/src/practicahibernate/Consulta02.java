/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicahibernate;

import entity.Conductor;
import entity.Persona;
import java.util.Date;
import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.NewHibernateUtil;

/**
 *
 * @author seran
 */
public class Consulta02 {

    //Tipo de infracción cuya multa supere los 500€
    public static void main(String[] args) {
        SessionFactory sfactory = NewHibernateUtil.getSessionFactory();
    	Session session = sfactory.openSession();
        
        //Cogemos la información de las 2 tablas para trabajr con ellas
        Query q1 = session.createQuery("from Conductor");
        Query q2 = session.createQuery("from Persona");
        
        //Ponemos las tablas en distintos iterator
        Iterator<?> iter1 = q1.iterate();
        Iterator<?> iter2 = q2.iterate();

        System.out.println("Personas con el la fecha expirada");
        while (iter1.hasNext()) {
            //Empezamos a recorrer los conductores
            Conductor result1 = (Conductor) iter1.next();
            //Miramos si la fecha es menor la de hoy
            if (result1.getFechaExpiracion().before(new Date())) {
                //Si se da la coindicendia se recorre el otro en busca
                //De una persona que tenga la misma ID que el conductor
                while (iter2.hasNext()) {
                    Persona result2 = (Persona) iter2.next();
                    //Si lo encuentra lo imprime
                    if (result1.getIdpersona() == result2.getIdpersona()) {
                        System.out.println("=================================");
                        System.out.println("ID: " + result2.getIdpersona() + " // Nombre: " + result2.getNombre() + " // Fecha: " + result1.getFechaExpiracion() );
                    }
                }
            }
            //Ddevolvemos el puntero de persona al principio
            iter2 = q2.iterate();
        }
        session.close();
    }
    
}
