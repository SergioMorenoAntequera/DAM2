/*
 *    Qizx Free_Engine-4.4
 *
 *    This code is part of Qizx XQuery engine
 *    Copyright (c) 2004-2010 Axyana Software -- All rights reserved.
 *
 *    For conditions of use, see the accompanying license files.
 */
package com.qizx.api.util.backup;

import com.qizx.api.LibraryException;
import com.qizx.util.basic.IntSet;
import com.qizx.xlib.blobs.BlobException;

/**
 * Low-level input interface for Backup.
 * <p>
 * Supports full- and incremental backup.
 */
public interface BackupSession
{
    // datasets:
    int DOCS = 0, METADOCS = 1;

    int getVersion();

    /**
     * Returns a list of signatures/digests for "pages" of MicroFile/Blob
     * identifiers. This is used to quickly identify pages where changes occurred.
     */
    long[] getPageDigests(int pageSize); // TODO future: add a 'storageId' param

    /**
     * Gets a set of identifiers (within a "page") of actually existing MicroFiles.
     */
    IntSet getFileIds(int/*Fid*/firstFid, int pageSize);

    /**
     * Returns the total size of a set of microfiles
     * @param toCopy a set of microfiles
     * @throws BlobException 
     */
    long getMicroFilesSize(IntSet toCopy);

    /**
     * Get identifiers, sizes and digests of index segments for dataset.
     */
    long[] getSegments(int dataset);

    /**
     * Starts reading a microfile as a sequence of blocks
     * @param fileId
     * @return the number of blocks
     */
    long beginMicroFile(int/*Fid*/fileId)
        throws LibraryException;

    /**
     * Starts reading a segment as a sequence of blocks
     * @param segId
     * @return the number of blocks
     */
    long beginSegment(int dataset, int segId)
        throws LibraryException;

    /**
     * Ends reading a segment 
     */
    void endSegment(int dataset)
        throws LibraryException;

    /**
     * Returns the block size of the current microfile.
     */
    int getBlockSize();

    /**
     * Returns the compression level of the current microfile.
     * @return 0 if not compressed, 1 to 9 if compressed.
     */
    int getCompression();

    /**
     * Gets the bytes of the current block.
     * @param buffer should be large enough to hold the block size
     * @return actual size of the block. This is the raw size (compressed if
     *         compression is used).
     */
    int getBlockBytes(byte[] buffer);

    /**
     * Closes the target XML Library and releases resources.
     */
    void close()
        throws LibraryException;
}
