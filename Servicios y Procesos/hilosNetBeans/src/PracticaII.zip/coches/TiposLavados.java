package coches;

public enum TiposLavados {
    NORMAL, EXTRA, SUPER;
}
