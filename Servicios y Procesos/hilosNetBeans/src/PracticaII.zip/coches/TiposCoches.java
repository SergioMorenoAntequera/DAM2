package coches;

public enum TiposCoches {
    NORMAL, MEDIANO, GRANDE;
}
