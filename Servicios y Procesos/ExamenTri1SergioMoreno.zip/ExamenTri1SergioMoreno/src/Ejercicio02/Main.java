/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio02;

import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author examen
 */
public class Main {
    
    static int nProfesores;
    static Alumno[] alumnos;
    static Profesor[] profesores;
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        //Como en el ejercicio anterior cada alumno velverá atener 2 practicas
        String[] nPracticas = {"Pr1", "Pr2"};
        //Creamos los alumnos
        alumnos = new Alumno[20];
        for(int i = 0; i<20; i++){
            int[] tPracticas1 = {(int)(Math.random()*5+1), (int)(Math.random()*5+1)};
            alumnos[i] = new Alumno("Alum_"+i, nPracticas, tPracticas1);
        }
        System.out.println("20 alumnos creados");
        System.out.println("==================");
        boolean valido = false;
        while (!valido){
        System.out.println("¿Cuantos profesores tienes? (2-10)");
            nProfesores = sc.nextInt();
            if(nProfesores >= 2 && nProfesores <=10){
                valido = true;
            } else {
                System.out.println("Numero de profesores no valido");
            }
        }
        
        profesores = new Profesor[nProfesores];
        for (int i = 0; i < nProfesores; i++) {
            profesores[i] = new Profesor("prof_" + i);
        }
        
        long tiempoInicio = System.currentTimeMillis();
        
        ExecutorService executor = Executors.newFixedThreadPool(nProfesores);
            for (Alumno alum : alumnos) {
                Runnable profesor = new Hilo(alum, tiempoInicio);
                executor.execute(profesor);
            }
        //Hilos lanzados
        executor.shutdown(); //Cerramos el executor para poder terminar
        while (!executor.isTerminated()) {
            //Mantenemos el programa hasta que se acabe el executor
        }

    }
}
