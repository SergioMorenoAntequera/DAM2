/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio02;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Hilo implements Runnable{
    
    private Alumno alum;
    //private Profesor prof;
    int tiempoProfesor;
    long tiempo;
    
    public Hilo(Alumno alum, long tiempo){
        this.alum = alum;
        this.tiempo = tiempo;
        tiempoProfesor = 0;
    }
    
    @Override
    public void run(){
        for(int i = 0; i < 2; i++) {
            System.out.println("Profesor " + Thread.currentThread().getName() + " corrigiendo práctica " + alum.getnPracticas()[i] + " del alumno: \n"
                    + alum.getNombre() + ", en un timepo de " + alum.gettPracticas()[i]);
            tiempoProfesor+=alum.gettPracticas()[i];
            try {
                Thread.sleep(alum.gettPracticas()[i] * 1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
            }
            if(i<1){
                System.out.println("---------------");
                System.out.println("Don/Doña " + Thread.currentThread().getName() + " pasando a la siguiente práctica");
                System.out.println("---------------");
            }
            
        }
        System.out.println("================");
        System.out.println(">>>Don/Doña " + Thread.currentThread().getName() + " YA HA TERMINADO DE CORREGIR \n Ha tardado " + tiempoProfesor + " segundos");
        System.out.println("================");
    }
}
