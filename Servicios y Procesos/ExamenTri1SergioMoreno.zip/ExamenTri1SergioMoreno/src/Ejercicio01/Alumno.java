/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio01;

/**
 *
 * @author examen
 */
public class Alumno {
    
    private String nombre;
    private String[] nPracticas;
    private int[] tPracticas;

    public Alumno(String nombre, String[] nPracticas, int[] tPracticas) {
        this.nombre = nombre;
        this.nPracticas = nPracticas;
        this.tPracticas = tPracticas;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String[] getnPracticas() {
        return nPracticas;
    }
    public void setnPracticas(String[] nPracticas) {
        this.nPracticas = nPracticas;
    }
    public int[] gettPracticas() {
        return tPracticas;
    }
    public void settPracticas(int[] tPracticas) {
        this.tPracticas = tPracticas;
    }
}
