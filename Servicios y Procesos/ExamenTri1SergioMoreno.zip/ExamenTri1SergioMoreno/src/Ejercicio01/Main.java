/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio01;

/**
 *
 * @author examen
 */
public class Main {
    
    static int tiempoTotal;
    
    public static void main(String[] args){
        
        //Todos los alumnos han entregado 2 prácticas
        String[] nPracticas = {"Pr1", "Pr2"};
        int[] tPracticas1 = {2, 4};
        int[] tPracticas2 = {1, 2};
        int[] tPracticas3 = {6, 5};
        int[] tPracticas4 = {1, 1};
        int[] tPracticas5 = {3, 2};
        Alumno alum1 = new Alumno("Juan", nPracticas, tPracticas1);
        Alumno alum2 = new Alumno("Maria", nPracticas, tPracticas2);
        Alumno alum3 = new Alumno("Pedro", nPracticas, tPracticas3);
        Alumno alum4 = new Alumno("Raul", nPracticas, tPracticas4);
        Alumno alum5 = new Alumno("Marta", nPracticas, tPracticas5);
        System.out.println("Alumnos creados");
        
        Profesor prof1 = new Profesor("Paco");
        Profesor prof2 = new Profesor("Begoña");
        Profesor prof3 = new Profesor("Filo");
        Profesor prof4 = new Profesor("Fran");
        Profesor prof5 = new Profesor("Dolores");
        System.out.println("Profesores creados");
        
        Hilo hilo1 = new Hilo(alum1, prof1);
        Hilo hilo2 = new Hilo(alum2, prof2);
        Hilo hilo3 = new Hilo(alum3, prof3);
        Hilo hilo4 = new Hilo(alum4, prof4);
        Hilo hilo5 = new Hilo(alum5, prof5);
        
        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo4.start();
        hilo5.start();
        
        while(hilo1.isAlive() || hilo2.isAlive() || hilo3.isAlive() || hilo4.isAlive() || hilo5.isAlive()){
            
        }
        System.out.println("----------------------------------");
        System.out.println("----------------------------------");
        System.out.println("----------------------------------");
        System.out.println("Todas las practicas corregidas, timepo total:" + tiempoTotal);
    }
}
