/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio04;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Imprenta {
    
    private boolean lleno = false;
    private String cadena;
    
    public synchronized void poner(String cadena){
        while(lleno){
            esperar();
        }
        lleno = true;
        
        int tDurmiendo = (int) (Math.random() * 2 + 2);
        dormir(tDurmiendo * 1000);

        System.out.println(" + Poniendo: " + cadena);
        this.cadena = cadena;
        notify();
    }
    
    
    public synchronized String retirar(){
        while(!lleno){
            esperar();
        }
        lleno = false;
        dormir(3000);
        System.out.println(" - Retirando: " + cadena);
        notify();
        return this.cadena;
    }
    
    public void setCadena(String cadena){
        this.cadena = cadena;
    }
    public String getCadena(){
        return this.cadena;
    }
    public void esperar(){
        try {
            wait();
        } catch (InterruptedException ex) {
        }
    }
    
    public void dormir(long tiempo){
        try {
            Thread.sleep(tiempo);
        } catch (InterruptedException ex) {
            Logger.getLogger(Impresor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
