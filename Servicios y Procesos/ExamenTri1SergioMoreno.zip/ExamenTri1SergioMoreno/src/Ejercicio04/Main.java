/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio04;

/**
 *
 * @author examen
 */
public class Main {
    
    public static void main(String[] args){
        
        Imprenta c = new Imprenta();
        
        Escritor escritor = new Escritor(c);
        Impresor impresor = new Impresor(c);
        
        escritor.start();
        impresor.start();
    }
    
}
