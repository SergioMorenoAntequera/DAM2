/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio04;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Impresor extends Thread {
    
    private String cadena;
    Imprenta c; 
    
     public Impresor(Imprenta c){
         this.c = c;
     }

    @Override
    public void run(){
        while(true){
            
            cadena = c.retirar();
            dormir(3000);
        }
    }
    
    public void dormir(long tiempo){
        try {
            Thread.sleep(tiempo);
        } catch (InterruptedException ex) {
            Logger.getLogger(Impresor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
