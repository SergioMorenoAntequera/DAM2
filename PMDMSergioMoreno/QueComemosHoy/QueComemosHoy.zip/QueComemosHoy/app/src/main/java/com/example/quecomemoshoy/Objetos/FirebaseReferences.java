package com.example.quecomemoshoy.Objetos;

public class FirebaseReferences {

    final public static String RECETAS_REFERENCE = "Recetas";
    final public static String USUARIOS_REFERENCE = "Usuarios";

}
