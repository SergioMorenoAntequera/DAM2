package com.example.seran.p06aplicacionrepaso;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class layout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);
    }
}
